# traffic_management 4 > 2024-04-22 2:15pm
https://universe.roboflow.com/project-q3v8e/traffic_management-4

Provided by a Roboflow user
License: CC BY 4.0

